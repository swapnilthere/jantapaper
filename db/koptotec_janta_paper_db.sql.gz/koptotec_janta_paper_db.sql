-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 07, 2023 at 11:07 PM
-- Server version: 10.5.17-MariaDB-cll-lve
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `koptotec_janta_paper_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `client_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pan` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gst` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `client_name`, `email`, `address`, `phone`, `pan`, `gst`, `username`, `password`) VALUES
(12, 'NIRMAN CORPORATION', 'hryday@saaro.in', 'A/7 MARU SADAN D.L VAIDYA ROAD DADAR WEST', '9930808308', 'AAMFN4372N', '27AAMFN4372N1ZL', 'nirman', '$2y$10$pMfoQdUwJpcMuFFzrcR5PeMokjzBkrDpun549KhWcMhOP/y6MWjKy'),
(13, 'PAREKH SALES AGENCY', 'swastiksalescorporation1@gmail.com', 'C 23, 2ND FLOOR, ROYAL IND EST , NAIGAON CROSS ROAD, WADALA MUM - 31', '8591689746', 'AACPP6753B', '27AACPP6753B1ZS', 'PAREKH', '$2y$10$mc2M6iYw9s.dTP1UVm88oOjdaWiF9ivLzL4qwv/4R3QqZof/PP83e'),
(14, 'RUKSON PACKAGING PVT LTD', 'rukson@gmail.com', 'R 273, TTC INDUSTRIAL AREA LTD, NEAR BANK OF BARODA, RABALE MUM - 400612', '02227690198', 'AAACJ4374M', '27AAACJ4374M1Z7', 'RUKSON', '$2y$10$H5jeTlo9oYx94cPcVpHXmu0YZHUU4tm6NaTHuWa7Z8g7sOJtKpEMG'),
(15, 'INFINITY INDUSTRIES PVT LTD', 'rohini.jadhav@einfinity.in', 'HAROON HOUSE, 1ST FLOOR, 294 PERIN NARIMAN STREET, OPP RBI , FORT MUM - 01', '02222672288', 'AAACI8002P', '27AAACI8002P1ZD', 'INFINITY', '$2y$10$5hXHlzjx7sddDmKc3hYCC.rb9XltD67410eFKm3pLcWXh9MZqpcG.'),
(16, 'testuser', 'testuser@yopmail.com', 'testuser', '9988776655', 'afds', 'fdsfs', 'testuser', '$2y$10$afJLlH0RLRGhhQmG4sSoDOOS0sSOUxugTqQB3chwfm9Q3PQHACo4S'),
(17, 'PRINTSOUK', 'info@printsouk.in', 'SHED NO-2, CONNAUGHT SAW MILL,COMPOUND,D.P.WADI GHODAPDEO,OPP LUWANA BHAVAN BYCULLA,MUMBAI,400033', '9167685933', 'BHAPP8458D', '27BHAPP8458D1Z5', 'PRINTSOUK', '$2y$10$0P9.uhf2.zH0ablF75lovOdCys2nUIpiD7KBRNV5nAbJQev2JStC2'),
(18, 'RELIABLE PAPER MART', 'info@reliablepapermart.com', 'H-6,GUPTA WAREHOUSE COMPLEX,DAPODE,BHIWANDI,THANE,421302', '22094033', 'BARPG0834L', '27BARPG0834L1ZE', 'RELIABLE PAPER MART', '$2y$10$4m/K4JHUXSxGoGB6iiu.O.GsoTt1vuI.Svb/wP8aAy9ODgt2GFt3G'),
(19, 'T.K.RUBY & CO.', 'info@tkruby.in', '1st FLR 11,RUSTOM SIDHWA MARG,NANABHOY CHAMBER,FORT,MUMBAI,400001', '9820355323', 'AAKFT0493Q', '27AAKFT0493Q1ZD', 'T.K.RUBY & CO.', '$2y$10$Sc1Ygj44EKxT0EWdzrrZUeeKh8k1t.xmew8tRZ6FO9A.vl7PUY1RW'),
(20, 'SAN', 'vdpat@dr.com', '15 Jaiprakash Road, Mumbai 400058', '9820356506', 'AALCS8974R', '27AALCS8974R1ZZ', 'SAN', '$2y$10$zqapEAxvraKPjg22Cn8ER.YJmtJ1uul0aIDVXMy0NyZJZlBT.AjLO');

-- --------------------------------------------------------

--
-- Table structure for table `material_type`
--

CREATE TABLE `material_type` (
  `id` int(11) NOT NULL,
  `material` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `material_type`
--

INSERT INTO `material_type` (`id`, `material`, `parent_id`) VALUES
(6, 'TUFFCOTE', 0),
(7, 'ULTIMA', 0),
(8, 'PKT', 7),
(10, 'Ream', 12),
(11, 'sheet', 6),
(12, 'maplitho', 0),
(13, 'rolls', 14),
(14, 'itc cyber', 0),
(17, 'PKT', 6),
(18, 'Xyz', 0),
(19, 'Sheet', 18),
(20, 'Roll', 18);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` int(11) NOT NULL,
  `invoice_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bhd` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transportation_charges` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vehicle_num` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `status`, `date`, `client_id`, `invoice_number`, `bhd`, `transportation_charges`, `vehicle_num`, `address`) VALUES
(2, 'Dispatched', '2023-06-07 05:08:17', 4, '557598', '96986986', '900', 'MH01BJ7209', ''),
(3, 'Dispatched', '2023-06-07 05:12:47', 4, '557598', '96986986', '900', 'MH01BJ7209', ''),
(4, 'Dispatched', '2023-06-07 06:01:00', 4, '001', '100', '500', 'MH04EY0707', ''),
(5, 'Dispatched', '2023-06-08 09:31:28', 5, '123', '123', '500', 'mh 04jk1752', ''),
(6, 'Dispatched', '2023-06-09 07:50:33', 4, '111', '111', '10', 'mh43ay4572', ''),
(7, 'Dispatched', '2023-06-16 10:51:37', 5, '01', '01', '25', 'mh04jk7130', ''),
(8, 'Dispatched', '2023-06-22 05:47:54', 4, 'INV001', 'BHD001', '100', 'MH08MF9989', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(9, 'Dispatched', '2023-06-22 08:03:47', 5, '02', '02', '01', 'mh 04jk1752', '54 dadiseth agairi lane'),
(10, 'Dispatched', '2023-06-22 08:08:08', 4, 'INV001', 'BHD001', '100', 'MH08MF9989', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(11, 'Dispatched', '2023-06-22 08:09:04', 4, 'INV001', 'BHD001', '100', 'MH08MF9989', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(12, 'Dispatched', '2023-06-22 08:10:43', 4, '02', '02', '01', 'mh 04jk1752', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(13, 'Dispatched', '2023-06-22 08:38:00', 5, '120', '100', '500', 'MH04EY0707', '54 dadiseth agairi lane'),
(14, 'Dispatched', '2023-06-23 00:55:41', 5, 'INV001', 'BHD001', '100', 'MH08MF9989', '54 dadiseth agairi lane'),
(15, 'Dispatched', '2023-06-27 01:52:18', 4, 'INV001', 'BHD', '100', '100', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(16, 'Received', '2023-06-27 09:40:11', 4, '', '', '', '', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(17, 'Dispatched', '2023-06-30 10:11:19', 6, '05', '05', '50', 'mh04jk7130', '54 dadiseth agairi lane'),
(18, 'Dispatched', '2023-06-30 10:15:46', 6, '02', '02', '500', 'mh43ay4572', '54 dadiseth agairi lane'),
(19, 'Cancelled', '2023-06-30 10:38:24', 6, 'NA', 'NA', 'NA', 'NA', '54 dadiseth agairi lane'),
(20, 'Received', '2023-07-14 07:44:47', 4, '', '', '', '', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(21, 'Received', '2023-07-14 07:48:08', 4, '', '', '', '', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(22, 'Received', '2023-07-14 07:59:34', 4, '', '', '', '', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(23, 'Dispatched', '2023-07-14 08:00:42', 4, 'INv001', 'BHD001', '100', 'MH08MF9989', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(24, 'Received', '2023-07-15 01:07:37', 4, 'NA', 'NA', 'NA', 'NA', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(25, 'Dispatched', '2023-07-16 23:06:35', 4, 'INV001', 'BHD001', '100', 'MH08MF9989', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(26, 'Dispatched', '2023-07-17 06:52:45', 4, 'INV001', 'BHD001', '100', 'MH08MF9989', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(27, 'Dispatched', '2023-07-17 06:55:22', 4, 'INv001', 'BHD001', '100', 'MH08MF9989', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(28, 'Dispatched', '2023-07-17 07:41:37', 4, 'INV001', 'BHD001', '100', 'MH08MF9989', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(29, 'Dispatched', '2023-07-17 08:17:50', 4, 'INV001', 'BHD001', '100', 'MH08MF9989', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(30, 'Dispatched', '2023-07-18 10:33:24', 4, '02', '02', '01', 'mh 04jk1752', 'FLAT NO.1/0105,Challengers Co-op. Hsg. Soc. Ltd. Unit 1 Thakur Village, Kandivali (East) MUMBAI MH 400101 IN'),
(31, 'Pending', '2023-07-18 10:46:36', 9, '', '', '', '', '5  dadiseth agairi lane'),
(32, 'Pending', '2023-07-20 04:44:20', 10, '', '', '', '', 'Narayana Dham'),
(33, 'Pending', '2023-07-20 07:08:50', 11, '', '', '', '', 'teste'),
(34, 'Pending', '2023-07-20 07:37:11', 5, '', '', '', '', '54 dadiseth agairi lane'),
(35, 'Pending', '2023-07-27 07:12:29', 12, '', '', '', '', 'A/7 MARU SADAN D.L VAIDYA ROAD DADAR WEST'),
(36, 'Pending', '2023-07-27 07:30:36', 13, '', '', '', '', 'C 23, 2ND FLOOR, ROYAL IND EST , NAIGAON CROSS ROAD, WADALA MUM - 31'),
(37, 'Pending', '2023-07-27 07:50:58', 14, '', '', '', '', 'R 273, TTC INDUSTRIAL AREA LTD, NEAR BANK OF BARODA, RABALE MUM - 400612'),
(38, 'Pending', '2023-07-27 07:59:27', 15, '', '', '', '', 'HAROON HOUSE, 1ST FLOOR, 294 PERIN NARIMAN STREET, OPP RBI , FORT MUM - 01'),
(39, 'Pending', '2023-07-27 12:28:07', 12, '', '', '', '', 'A/7 MARU SADAN D.L VAIDYA ROAD DADAR WEST'),
(40, 'Dispatched', '2023-07-29 05:55:52', 12, '1', '123', '1200', 'mh01dr1427', 'A/7 MARU SADAN D.L VAIDYA ROAD DADAR WEST '),
(41, 'Dispatched', '2023-07-29 08:48:05', 15, '2', '2', '10', 'mh43ay4572', 'HAROON HOUSE, 1ST FLOOR, 294 PERIN NARIMAN STREET, OPP RBI , FORT MUM - 01'),
(42, 'Dispatched', '2023-07-29 09:03:43', 12, '3', '3', '3', 'mh 04jk1752', 'A/7 MARU SADAN D.L VAIDYA ROAD DADAR WEST'),
(43, 'Dispatched', '2023-07-29 09:06:20', 13, '4', '4', '0', 'mh01dr1427', 'C 23, 2ND FLOOR, ROYAL IND EST , NAIGAON CROSS ROAD, WADALA MUM - 31'),
(44, 'Pending', '2023-07-29 09:09:01', 14, '', '', '', '', 'R 273, TTC INDUSTRIAL AREA LTD, NEAR BANK OF BARODA, RABALE MUM - 400612'),
(45, 'Pending', '2023-07-29 09:12:21', 15, '', '', '', '', 'HAROON HOUSE, 1ST FLOOR, 294 PERIN NARIMAN STREET, OPP RBI , FORT MUM - 01'),
(46, 'Cancelled', '2023-07-29 09:49:32', 13, 'NA', 'NA', 'NA', 'NA', '54 DADI SETH AGIYAI LANE KALBADEVI MUMBAI 400002'),
(47, 'Dispatched', '2023-07-29 10:00:19', 15, '1', '123', '0', 'mh01dr1427', '54 DADI SETH AGIYARI LANE KALBADEVI MUMBAI.400002'),
(48, 'Pending', '2023-08-08 04:31:12', 16, '', '', '', '', 'testuser'),
(49, 'Pending', '2023-08-08 04:46:52', 16, '', '', '', '', 'testuser'),
(50, 'Dispatched', '2023-08-14 09:33:27', 17, '1', '123', '0', 'mh01dr1427', 'SHED NO-2, CONNAUGHT SAW MILL,COMPOUND,D.P.WADI GHODAPDEO,OPP LUWANA BHAVAN BYCULLA,MUMBAI,400033'),
(51, 'Dispatched', '2023-08-14 09:38:34', 15, '123', '123', '0', 'mh01dr1427', 'BHIWANDI'),
(52, 'Dispatched', '2023-08-14 09:40:59', 17, '1', '123', '0', 'mh01dr1427', 'SHED NO-2, CONNAUGHT SAW MILL,COMPOUND,D.P.WADI GHODAPDEO,OPP LUWANA BHAVAN BYCULLA,MUMBAI,400033'),
(53, 'Pending', '2023-08-14 09:48:12', 17, '', '', '', '', 'BHIWANDI'),
(54, 'Pending', '2023-08-14 10:01:43', 17, '', '', '', '', 'SHED NO-2, CONNAUGHT SAW MILL,COMPOUND,D.P.WADI GHODAPDEO,OPP LUWANA BHAVAN BYCULLA,MUMBAI,400033'),
(55, 'Pending', '2023-08-18 03:24:56', 16, '', '', '', '', 'testuser'),
(56, 'Pending', '2023-08-18 04:04:58', 16, '', '', '', '', 'testuser'),
(57, 'Dispatched', '2023-08-21 09:46:56', 12, '1', '123', '0', 'mh01dr1427', 'A/7 MARU SADAN D.L VAIDYA ROAD DADAR WEST'),
(58, 'Dispatched', '2023-08-21 09:49:19', 13, '4', '4', '0', 'mh01dr1427', 'C 23, 2ND FLOOR, ROYAL IND EST , NAIGAON CROSS ROAD, WADALA MUM - 31'),
(59, 'Dispatched', '2023-09-12 09:11:12', 12, 'INV001', 'BHD001', '0', 'MH08MF9989', 'A/7 MARU SADAN D.L VAIDYA ROAD DADAR WEST'),
(60, 'Dispatched', '2023-09-19 08:59:03', 12, '1', '1', '01', '1', 'A/7 MARU SADAN D.L VAIDYA ROAD DADAR WEST'),
(61, 'Received', '2023-09-19 09:01:05', 14, 'NA', 'NA', 'NA', 'NA', 'R 273, TTC INDUSTRIAL AREA LTD, NEAR BANK OF BARODA, RABALE MUM - 400612'),
(62, 'Dispatched', '2023-09-21 14:14:21', 20, '1239', '027', '900', 'MH01I9810', '15 Jaiprakash Road, Mumbai 400058'),
(63, 'Received', '2023-09-29 15:13:54', 12, 'NA', 'NA', 'NA', 'NA', 'A/7 MARU SADAN D.L VAIDYA ROAD DADAR WEST');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `height_inch` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `width_inch` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `mark_status` int(1) NOT NULL DEFAULT 0,
  `conversion` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `height_inch`, `width_inch`, `quantity`, `product_id`, `mark_status`, `conversion`) VALUES
(1, 2, '25.4', '38', 45, 9, 0, 0),
(2, 3, '10', '10', 2, 8, 1, 0),
(3, 4, '91.5', '91.5', 10, 10, 0, 0),
(4, 5, '20', '20', 10, 11, 2, 0),
(5, 6, '50', '50', 1, 8, 0, 0),
(6, 7, '78', '78', 1, 8, 0, 0),
(7, 7, '36', '36', 20, 12, 0, 0),
(8, 8, '100', '100', 1, 8, 0, 0),
(9, 8, '27', '27', 1, 9, 0, 0),
(10, 9, '23', '23', 1, 13, 0, 0),
(11, 10, '100', '100', 1, 8, 0, 0),
(12, 11, '100', '100', 1, 8, 0, 0),
(13, 12, '30', '30', 2, 13, 0, 0),
(14, 13, '76.5', '76.5', 2, 14, 0, 0),
(15, 13, '76.5', '76.5', 2, 14, 0, 0),
(16, 14, '10', '10', 1, 8, 0, 0),
(17, 15, '23', '36', 1, 13, 0, 0),
(18, 15, '76.5', '58.5', 2, 14, 0, 0),
(19, 15, '10', '20', 1, 8, 1, 0),
(20, 16, '100', '200', 1, 8, 0, 0),
(21, 17, '37', '26', 20, 15, 0, 0),
(22, 18, '100', '105', 3, 8, 1, 0),
(23, 18, '91.5', '63.5', 40, 10, 0, 0),
(24, 19, '25', '36', 10, 12, 0, 0),
(25, 20, '100', '200', 10, 8, 0, 0),
(26, 20, '100', '200', 5, 8, 0, 0),
(27, 21, '100', '50', 10, 16, 0, 0),
(28, 22, '37', '26', 25, 15, 0, 0),
(29, 22, '37', '26', 1, 15, 0, 0),
(30, 23, '25', '36', 1, 12, 0, 0),
(31, 23, '27', '54', 1, 9, 0, 0),
(32, 24, '10', '50', 1, 16, 2, 0),
(33, 25, '10', '50', 5, 16, 0, 0),
(34, 26, '50', '200', 5, 8, 0, 0),
(35, 27, '100', '100', 1, 8, 0, 0),
(36, 28, '100', '100', 1, 8, 0, 0),
(37, 29, '100', '50', 2, 8, 0, 0),
(38, 30, '25', '36', 7, 12, 0, 0),
(39, 31, '25', '36', 2, 12, 0, 0),
(40, 32, '100', '200', 9, 8, 0, 0),
(41, 32, '100', '200', 3, 8, 0, 0),
(42, 32, '100', '200', 3, 8, 0, 0),
(43, 33, '100', '200', 1, 8, 0, 0),
(44, 34, '105.5', '80', 12, 18, 0, 0),
(45, 35, '86.5', '63.5', 8, 19, 0, 0),
(46, 35, '91.5', '63.5', 4, 20, 0, 0),
(47, 36, '71', '51', 26, 21, 0, 0),
(48, 37, '86.5', '58.5', 15, 22, 0, 0),
(49, 38, '25.4', '38', 6, 23, 0, 0),
(50, 39, '14.96', '10.00', 1, 19, 0, 1),
(51, 40, '24.02', '22.05', 1, 27, 0, 1),
(52, 41, '20.10', '31.26', 10, 101, 0, 0),
(53, 42, '41.47', '31.89', 5, 119, 0, 0),
(54, 43, '27.56', '21.65', 1, 117, 0, 1),
(55, 43, '32.68', '19.69', 1, 128, 0, 1),
(56, 44, '27.56', '21.65', 1, 117, 0, 1),
(57, 44, '36.61', '25.00', 1, 26, 0, 1),
(58, 45, '18.90', '28.35', 1, 35, 0, 1),
(59, 45, '27.95', '20.08', 1, 21, 0, 1),
(60, 46, '47.24', '27.95', 1, 124, 0, 1),
(61, 47, '35.04', '27.36', 1, 125, 0, 1),
(62, 48, '32.56', '22.05', 1, 28, 0, 1),
(63, 49, '12', '18', 1, 144, 1, 0),
(64, 50, '20.51', '15.00', 15, 129, 2, 0),
(65, 51, '15', '15.00', 10, 129, 0, 0),
(66, 52, '45.67', '31.89', 2, 120, 0, 1),
(67, 52, '21.65', '25.59', 2, 29, 0, 1),
(68, 52, '21.65', '25.59', 2, 29, 0, 1),
(69, 53, '29.53', '19.69', 4, 33, 0, 1),
(70, 54, '33.07', '28.74', 1, 131, 0, 1),
(71, 54, '33.07', '28.74', 1, 131, 0, 1),
(72, 55, '3.54', '4.72', 1, 143, 0, 1),
(73, 56, '10.63', '9.84', 1, 24, 0, 1),
(74, 57, '25.20', '29.53', 1, 132, 0, 1),
(75, 58, '25.20', '19.69', 1, 132, 0, 1),
(76, 59, '11.81', '7.87', 1, 25, 0, 1),
(77, 60, '23.23', '37.01', 15, 36, 0, 0),
(78, 61, '31', '19.69', 10, 128, 0, 0),
(79, 62, '3.54', '35.43', 3, 144, 0, 1),
(80, 63, '32.48', '24.61', 1, 25, 0, 0),
(81, 63, '32.48', '24.61', 1, 25, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `material_type` varchar(100) NOT NULL,
  `mat_sub_type` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `gsm` int(11) NOT NULL,
  `sku` varchar(10) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit` varchar(25) NOT NULL,
  `width` varchar(25) NOT NULL,
  `height` varchar(25) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `weight` varchar(20) DEFAULT NULL,
  `conversion` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `material_type`, `mat_sub_type`, `location`, `gsm`, `sku`, `quantity`, `unit`, `width`, `height`, `brand`, `weight`, `conversion`) VALUES
(19, '7', '8', 'BHD', 350, 'S001', 0, '100', '25.4', '38', 'JK ULTIMA', '132', '0'),
(20, '7', '8', 'BHD', 290, 'S002', 0, '100', '63.5', '91.5', 'JK ULTIMA', '67.2', '1'),
(21, '6', '17', 'BHD', 300, 'S003', 0, '100', '51', '71', 'JK TUFFCOTE', '283.4', '1'),
(22, '6', '17', 'BHD', 290, 'S004', 0, '100', '58.5', '86.5', 'JK TUFFCOTE', '220.5', '1'),
(23, '6', '17', 'BHD', 350, 'S005', 0, '350', '63.5', '81.3', 'JK TUFFCOTE', '99', '1'),
(24, '6', '17', 'bwj', 180, '01', 0, '200', '50', '54.5', 'tuffcote', '0', '1'),
(25, '6', '17', 'bwj', 185, '02', -1, '200', '62.5', '82.5', 'TUFFCOTE', '0', '1'),
(26, '6', '17', 'BWJ', 185, '03', 1, '200', '63.5', '93', 'TUFFCOTE', '10', '1'),
(27, '6', '17', 'BWJ', 185, '04', 78, '200', '56', '61', 'TUFFCOTE', '10', '1'),
(28, '6', '17', 'BWJ', 185, '05', 3, '200', '56', '82.7', 'TUFFCOTE', '10', '1'),
(29, '6', '17', 'BWJ', 185, '06', 5, '200', '65', '55', 'TUFFCOTE', '10', '1'),
(30, '6', '17', 'BWJ', 185, '07', 19, '200', '49', '90', 'TUFFCOTE', '10', '1'),
(31, '6', '17', 'BWJ', 190, '08', 8, '200', '63', '0', 'TUFFCOTE', '10', '1'),
(32, '6', '17', 'BWJ', 190, '09', 12, '200', '85', '61', 'TUFFCOTE', '10', '1'),
(33, '6', '17', 'BWJ', 190, '10', 0, '200', '50', '75', 'TUFFCOTE', '10', '1'),
(34, '6', '17', 'BWJ', 190, '11', 18, '200', '76', '77', 'TUFFCOTE', '10', '1'),
(35, '6', '17', 'BWJ', 190, '12', 0, '200', '72', '48', 'TUFFCOTE', '10', '1'),
(36, '6', '17', 'BWJ', 200, '13', 1, '200', '94', '59', 'TUFFCOTE', '10', '1'),
(37, '6', '17', 'BWJ', 200, '14', 63, '200', '56', '84', 'TUFFCOTE', '10', '1'),
(38, '6', '17', 'BWJ', 200, '15', 91, '200', '84', '56', 'TUFFCOTE', '10', '1'),
(39, '6', '17', 'BWJ', 200, '16', 1, '200', '82', '56', 'TUFFCOTE', '10', '1'),
(40, '6', '17', 'BWJ', 200, '17', 9, '200', '77', '98', 'TUFFCOTE', '10', '1'),
(41, '6', '17', 'BWJ', 200, '18', 40, '200', '57.5', '86.5', 'TUFFCOTE', '10', '1'),
(42, '6', '17', 'BWJ', 200, '19', 50, '200', '58', '90', 'TUFFCOTE', '10', '1'),
(43, '6', '17', 'BWJ', 200, '20', 2, '200', '62.5', '75', 'TUFFCOTE', '10', '1'),
(44, '6', '17', 'BWJ', 200, '21', 1, '200', '49.2', '0', 'TUFFCOTE', '10', '1'),
(45, '6', '17', 'BWJ', 210, '22', 15, '200', '60', '86', 'TUFFCOTE', '10', '1'),
(46, '6', '17', 'BWJ', 210, '23', 4, '200', '81.5', '68.5', 'TUFFCOTE', '10', '1'),
(47, '6', '17', 'BWJ', 210, '24', 2, '200', '70', '99', 'TUFFCOTE', '10', '1'),
(48, '6', '17', 'BWJ', 210, '25', 19, '200', '72', '73', 'TUFFCOTE', '10', '1'),
(49, '6', '17', 'BWJ', 210, '26', 1, '200', '73', '76', 'TUFFCOTE', '10', '1'),
(50, '6', '17', 'BWJ', 210, '27', 30, '200', '54', '85.5', 'TUFFCOTE', '10', '1'),
(51, '6', '17', 'BWJ', 210, '28', 1, '200', '56', '96.5', 'TUFFCOTE', '10', '1'),
(52, '6', '17', 'BWJ', 210, '29', 1, '200', '57', '70.5', 'TUFFCOTE', '10', '1'),
(53, '6', '17', 'BWJ', 210, '30', 3, '200', '57', '0', 'TUFFCOTE', '10', '1'),
(54, '6', '17', 'BWJ', 210, '31', 36, '200', '57', '91', 'TUFFCOTE', '10', '1'),
(55, '6', '17', 'BWJ', 210, '32', 10, '200', '57', '53.5', 'TUFFCOTE', '10', '1'),
(56, '6', '17', 'BWJ', 220, '33', 23, '200', '88.5', '87', 'TUFFCOTE', '10', '1'),
(57, '6', '17', 'BWJ', 220, '34', 7, '200', '77', '97.5', 'TUFFCOTE', '10', '1'),
(58, '6', '17', 'BWJ', 220, '35', 10, '200', '52.5', '86', 'TUFFCOTE', '10', '1'),
(59, '6', '17', 'BWJ', 220, '36', 1, '200', '60', '76', 'TUFFCOTE', '10', '1'),
(60, '6', '17', 'BWJ', 230, '37', 5, '200', '91.5', '124.5', 'TUFFCOTE', '10', '1'),
(61, '6', '17', 'BWJ', 230, '38', 2, '200', '90', '58.5', 'TUFFCOTE', '10', '1'),
(62, '6', '17', 'BWJ', 230, '39', 17, '200', '59', '85', 'TUFFCOTE', '10', '1'),
(63, '6', '17', 'BWJ', 230, '40', 24, '200', '58.5', '84', 'TUFFCOTE', '10', '1'),
(64, '6', '17', 'BWJ', 230, '41', 6, '200', '76', '96.5', 'TUFFCOTE', '10', '1'),
(65, '6', '17', 'BWJ', 230, '42', 1, '200', '80', '105.5', 'TUFFCOTE', '10', '1'),
(66, '6', '17', 'BWJ', 230, '43', 14, '200', '86', '61', 'TUFFCOTE', '10', '1'),
(67, '6', '17', 'BWJ', 230, '44', 2, '200', '61', '88.5', 'TUFFCOTE', '10', '1'),
(68, '6', '17', 'BWJ', 230, '45', 2, '200', '62', '88', 'TUFFCOTE', '10', '1'),
(69, '6', '17', 'BWJ', 230, '46', 1, '200', '57', '97', 'TUFFCOTE', '10', '1'),
(70, '6', '17', 'BWJ', 230, '47', 6, '200', '52.5', '70', 'TUFFCOTE', '10', '1'),
(71, '6', '17', 'BWJ', 230, '48', 48, '200', '70', '120', 'TUFFCOTE', '10', '1'),
(72, '6', '17', 'BWJ', 230, '49', 6, '200', '80', '120', 'TUFFCOTE', '10', '1'),
(73, '6', '17', 'BWJ', 230, '50', 3, '200', '89', '70.9', 'TUFFCOTE', '10', '1'),
(74, '6', '17', 'BWJ', 230, '51', 8, '200', '79', '57.5', 'TUFFCOTE', '10', '1'),
(75, '6', '17', 'BWJ', 230, '52', 7, '200', '57', '0', 'TUFFCOTE', '10', '1'),
(76, '6', '17', 'BWJ', 230, '53', 2, '200', '84', '90', 'TUFFCOTE', '10', '1'),
(77, '6', '17', 'BWJ', 230, '54', 2, '200', '88.5', '86.5', 'TUFFCOTE', '10', '1'),
(78, '6', '17', 'BWJ', 230, '55', 17, '200', '90', '86', 'TUFFCOTE', '10', '1'),
(79, '6', '17', 'BWJ', 230, '56', 8, '200', '88', '90.5', 'TUFFCOTE', '10', '1'),
(80, '6', '17', 'BWJ', 230, '57', 2, '200', '85', '69', 'TUFFCOTE', '10', '1'),
(81, '6', '17', 'BWJ', 230, '58', 8, '200', '67', '86', 'TUFFCOTE', '10', '1'),
(82, '6', '17', 'BWJ', 230, '59', 1, '200', '88.4', '75.1', 'TUFFCOTE', '10', '1'),
(83, '6', '17', 'BWJ', 230, '60', 3, '200', '78.5', '71', 'TUFFCOTE', '1', '1'),
(84, '6', '17', 'BWJ', 230, '61', 17, '200', '60.7', '71.7', 'TUFFCOTE', '10', '1'),
(85, '6', '17', 'BWJ', 230, '62', 11, '200', '61', '71', 'TUFFCOTE', '10', '1'),
(86, '6', '17', 'BWJ', 230, '63', 10, '200', '56', '68.5', 'TUFFCOTE', '10', '1'),
(87, '6', '17', 'BWJ', 230, '64', 26, '200', '51', '45', 'TUFFCOTE', '10', '1'),
(88, '6', '17', 'BWJ', 230, '65', 6, '200', '47.5', '97.6', 'TUFFCOTE', '10', '1'),
(89, '6', '17', 'BWJ', 240, '66', 24, '200', '87', '59', 'TUFFCOTE', '10', '1'),
(90, '6', '17', 'BWJ', 240, '67', 3, '200', '50', '85', 'TUFFCOTE', '10', '1'),
(91, '6', '17', 'BWJ', 240, '68', 8, '200', '86', '87.5', 'TUFFCOTE', '10', '1'),
(92, '6', '17', 'BWJ', 240, '69', 1, '200', '72.5', '84.8', 'TUFFCOTE', '10', '1'),
(93, '6', '17', 'BWJ', 240, '70', 8, '200', '70.2', '71.6', 'TUFFCOTE', '10', '1'),
(94, '6', '17', 'BWJ', 240, '71', 2, '200', '58.5', '74', 'TUFFCOTE', '10', '1'),
(95, '6', '17', 'BWJ', 240, '72', 46, '200', '58.5', '76', 'TUFFCOTE', '10', '1'),
(96, '6', '17', 'BWJ', 240, '73', 73, '200', '61', '72', 'TUFFCOTE', '10', '1'),
(97, '6', '17', 'BWJ', 240, '74', 1, '200', '67', '59', 'TUFFCOTE', '10', '1'),
(98, '6', '17', 'BWJ', 250, '75', 2, '200', '58.5', '91.5', 'TUFFCOTE', '10', '1'),
(99, '6', '17', 'BWJ', 250, '76', 57, '100', '60.5', '90', 'TUFFCOTE', '10', '1'),
(100, '6', '17', 'BWJ', 250, '77', 1, '200', '58.5', '90', 'TUFFCOTE', '10', '1'),
(101, '6', '17', 'BWJ', 250, '78', 249, '200', '79.4', '53.6', 'TUFFCOTE', '10', '1'),
(102, '6', '17', 'BWJ', 250, '79', 159, '100', '70', '100', 'TUFFCOTE', '10', '1'),
(103, '6', '17', 'BWJ', 250, '80', 3, '200', '80', '105.5', 'TUFFCOTE', '10', '1'),
(104, '6', '17', 'BWJ', 250, '81', 1, '200', '98.5', '100.5', 'TUFFCOTE', '10', '1'),
(105, '6', '17', 'BWJ', 250, '82', 3, '200', '98.5', '55.5', 'TUFFCOTE', '10', '1'),
(106, '6', '17', 'BWJ', 250, '83', 6, '200', '66', '89.6', 'TUFFCOTE', '10', '1'),
(107, '6', '17', 'BWJ', 250, '84', 18, '100', '64', '88', 'TUFFCOTE', '10', '1'),
(108, '6', '17', 'BWJ', 250, '85', 33, '200', '68.1', '67.2', 'TUFFCOTE', '10', '1'),
(109, '6', '17', 'BWJ', 250, '86', 21, '200', '88.5', '85.5', 'TUFFCOTE', '10', '1'),
(110, '6', '17', 'BWJ', 250, '87', 12, '200', '89.5', '85.5', 'TUFFCOTE', '10', '1'),
(111, '6', '17', 'BWJ', 250, '88', 1, '200', '85', '96.5', 'TUFFCOTE', '10', '1'),
(112, '6', '17', 'BWJ', 250, '89', 10, '100', '70', '90', 'TUFFCOTE', '10', '1'),
(113, '6', '17', 'BWJ', 250, '90', 4, '200', '90', '70', 'TUFFCOTE', '10', '1'),
(114, '6', '17', 'BWJ', 250, '91', 4, '200', '62.8', '81.3', 'TUFFCOTE', '10', '1'),
(115, '6', '17', 'BWJ', 250, '92', 4, '200', '80', '61', 'TUFFCOTE', '10', '1'),
(116, '6', '17', 'BWJ', 250, '93', 6, '200', '63.5', '56', 'TUFFCOTE', '10', '1'),
(117, '6', '17', 'BWJ', 250, '94', 1, '200', '55', '70', 'TUFFCOTE', '10', '1'),
(118, '6', '17', 'BWJ', 250, '95', 2, '200', '74.5', '72.8', 'TUFFCOTE', '10', '1'),
(119, '6', '17', 'BWJ', 260, '96', 8, '100', '81', '115.5', 'TUFFCOTE', '10', '1'),
(120, '6', '17', 'BWJ', 260, '97', 3, '100', '81', '116', 'TUFFCOTE', '10', '1'),
(121, '6', '17', 'BWJ', 260, '98', 2, '100', '57', '86', 'TUFFCOTE', '10', '1'),
(122, '6', '17', 'BWJ', 260, '99', 20, '100', '40', '77.4', 'TUFFCOTE', '10', '1'),
(123, '6', '17', 'BWJ', 265, '100', 1, '100', '71', '93.5', 'TUFFCOTE', '10', '1'),
(124, '6', '17', 'BWJ', 270, '101', 3, '100', '71', '120', 'TUFFCOTE', '10', '1'),
(125, '6', '17', 'BWJ', 270, '102', 6, '100', '69.5', '89', 'TUFFCOTE', '10', '1'),
(126, '6', '17', 'BWJ', 270, '103', 2, '100', '98.5', '93.5', 'TUFFCOTE', '10', '1'),
(127, '6', '17', 'BWJ', 270, '104', 3, '100', '84.7', '91.2', 'TUFFCOTE', '10', '1'),
(128, '6', '17', 'BWJ', 270, '105', 14, '100', '50', '83', 'TUFFCOTE', '10', '1'),
(129, '6', '17', 'BWJ', 270, '106', 39, '200', '38.1', '52.1', 'TUFFCOTE', '10', '1'),
(130, '6', '17', 'BWJ', 270, '107', 5, '100', '88', '71.5', 'TUFFCOTE', '10', '1'),
(131, '6', '17', 'BWJ', 270, '108', -1, '100', '73', '84', 'TUFFCOTE', '10', '1'),
(132, '6', '17', 'BWJ', 270, '109', 2, '100', '82', '64', 'TUFFCOTE', '10', '1'),
(133, '6', '17', 'BWJ', 270, '110', 1, '100', '79.6', '64', 'TUFFCOTE', '10', '1'),
(134, '6', '17', 'BWJ', 270, '111', 1, '100', '63.5', '76', 'TUFFCOTE', '10', '1'),
(135, '6', '17', 'BWJ', 270, '112', 4, '100', '65.1', '81.7', 'TUFFCOTE', '10', '1'),
(136, '6', '17', 'BWJ', 270, '113', 1, '100', '63', '61', 'TUFFCOTE', '10', '1'),
(137, '6', '17', 'BWJ', 270, '114', 4, '100', '85.2', '67', 'TUFFCOTE', '10', '1'),
(138, '6', '17', 'BWJ', 270, '115', 59, '100', '56', '71', 'TUFFCOTE', '10', '1'),
(139, '6', '17', 'BWJ', 270, '116', 1, '100', '53', '63', 'TUFFCOTE', '10', '1'),
(140, '6', '17', 'BWJ', 270, '117', 4, '100', '80', '99', 'TUFFCOTE', '10', '1'),
(141, '6', '17', 'BWJ', 270, '118', 2, '100', '40', '75', 'TUFFCOTE', '10', '1'),
(142, '18', '19', 'Test', 100, 'sku0010', 100, '10', '10', '12', 'Ultima', NULL, '0'),
(143, '18', '19', 'Test', 100, 'sku00112', 99, '10', '12', '18', 'test', '', '1'),
(144, '18', '20', 'Test', 100, 'SKU002', 96, '10', '100', '12', 'Premium', NULL, '0'),
(145, '6', '11', 'BWJ', 180, '01', 1, '200', '50', '54.5', 'TUFFCOTE', NULL, '1'),
(147, '7', '8', 'BWJ', 190, '02', 13, '200', '71', '90', 'ultima', NULL, '1'),
(148, '7', '8', 'BWJ', 190, '03', 2, '200', '71', '86.5', 'PLATINA', NULL, '1'),
(149, '7', '8', 'BWJ', 190, '04', 18, '200', '84', '65.5', 'ULTIMA', NULL, '0'),
(152, '7', '8', 'BWJ', 190, '02', 23, '200', '72', '72.5', 'ULTIMA', NULL, '1'),
(153, '7', '8', 'BWJ', 190, '03', 23, '200', '72', '72.5', 'ULTIMA', NULL, '1'),
(154, '6', '11', 'BWJ', 180, '1', 1, '200', '54.4', '50', 'TUFFCOTE', NULL, '1'),
(155, '6', '11', 'BWJ', 180, '2', 3, '200', '101.6', '55.8', 'TUFFCOTE', NULL, '1'),
(156, '6', '11', 'BWJ', 180, '3', 10, '200', '59', '54', 'TUFFCOTE', NULL, '1'),
(157, '6', '17', 'BWJ', 180, '4', 4, '200', '50', '54.5', 'TUFFCOTE', NULL, '1');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(150) NOT NULL,
  `created_at` date NOT NULL,
  `user_type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `created_at`, `user_type`) VALUES
(1, 'admin', '$2y$10$4N468uUwKgf84v.PiCZVyeQ1UyG4D0ijI0gB4Y0gaKZSOWnO6Pkz6', '0000-00-00', 1),
(2, 'staff1', '$2y$10$nIioW5UKcaCg6UmFtwKbv.cpx0xr3OylFsGEx1669qFvVJMQIvAjm', '0000-00-00', 4),
(3, 'user1', '$2y$10$esN1QJF3kdxNPYrY3eYlE.q/ZbAANzlvfBofppeYPs3v/ILMpFF6W', '0000-00-00', 3),
(4, 'abhijeet', '$2y$10$YU3OEOu9RZxCK6Ikl2rv6ODm4rVZ7eL7BO0LHx6cfoSGDMXmA8Uq6', '0000-00-00', 2),
(5, 'manager', '$2y$10$esN1QJF3kdxNPYrY3eYlE.q/ZbAANzlvfBofppeYPs3v/ILMpFF6W', '0000-00-00', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_cart`
--

CREATE TABLE `user_cart` (
  `id` int(11) NOT NULL,
  `selectedCustomer` int(11) NOT NULL,
  `height_inch` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width_inch` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `req_customization` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversion` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_cart`
--

INSERT INTO `user_cart` (`id`, `selectedCustomer`, `height_inch`, `width_inch`, `req_customization`, `quantity`, `productId`, `address`, `conversion`) VALUES
(102, 20, '20.51', '15.00', 0, 1, 129, '15 Jaiprakash Road, Mumbai 400058', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `material_type`
--
ALTER TABLE `material_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_cart`
--
ALTER TABLE `user_cart`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `material_type`
--
ALTER TABLE `material_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_cart`
--
ALTER TABLE `user_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

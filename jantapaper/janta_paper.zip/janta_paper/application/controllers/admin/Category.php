<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Category extends CI_Controller
{
    public function index()
    {
        $this->load->model('Category_model');
        $categories = $this->Category_model->getCategories();
        $data['categories'] = $categories;
        $this->load->view('admin/category/list', $data);
    }

    public function create()
    {
        $this->load->model('Category_model');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('name', 'Name', 'trim|required');
        $this->form_validation->set_rules('qtype', 'Quantity type', 'trim|required');
        $this->form_validation->set_rules('unit', 'Unit', 'trim|required');
        $this->form_validation->set_rules('location', 'Location', 'trim|required');
        $this->form_validation->set_rules('gsm', 'GSM', 'trim|required');
        $this->form_validation->set_rules('sku', 'SKU', 'trim|required');
        $this->form_validation->set_rules('quantity', 'Quantity', 'trim|required');
        $this->form_validation->set_rules('winch', 'Width', 'trim|required');
        $this->form_validation->set_rules('hinch', 'Height', 'trim|required');
        $this->form_validation->set_rules('brand', 'Brand', 'trim|required');

        $this->form_validation->set_error_delimiters('<p class="invalid_feedback">', '</p>');

        if ($this->form_validation->run() == TRUE) {
            $formArray['material_type'] = $this->input->post('name');
            $formArray['mat_sub_type'] = $this->input->post('qtype');
            $formArray['unit'] = $this->input->post('unit');
            $formArray['location'] = $this->input->post('location');
            $formArray['gsm'] = $this->input->post('gsm');
            $formArray['sku'] = $this->input->post('sku');
            $formArray['quantity'] = $this->input->post('quantity');
            $formArray['width'] = $this->input->post('winch');
            $formArray['height'] = $this->input->post('hinch');
            $formArray['brand'] = $this->input->post('brand');
            $this->Category_model->create($formArray);

            $this->session->set_flashdata('success', 'Stock added successfully');
            redirect(base_url() . 'admin/category/index');
        } else {
            $this->load->view('admin/category/create');
        }
    }

    public function edit($id)
    {
        // echo $id;
        $this->load->model('Category_model');
        $category = $this->Category_model->getCategory($id);

        if (empty($category)) {
            $this->session->set_flashdata('error', 'Category not found');
            redirect(base_url() . 'admin/category/index');
        }

        $this->load->model('Category_model');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('name', 'Name', 'trim|required');
        $this->form_validation->set_rules('qtype', 'Quantity type', 'trim|required');
        $this->form_validation->set_rules('unit', 'Unit', 'trim|required');
        $this->form_validation->set_rules('location', 'Location', 'trim|required');
        $this->form_validation->set_rules('gsm', 'GSM', 'trim|required');
        $this->form_validation->set_rules('sku', 'SKU', 'trim|required');
        $this->form_validation->set_rules('quantity', 'Quantity', 'trim|required');
        $this->form_validation->set_rules('winch', 'Width', 'trim|required');
        $this->form_validation->set_rules('hinch', 'Height', 'trim|required');
        $this->form_validation->set_rules('brand', 'Brand', 'trim|required');

        $this->form_validation->set_error_delimiters('<p class="invalid_feedback">', '</p>');

        if ($this->form_validation->run() == TRUE) {
            $formArray['material_type'] = $this->input->post('name');
            $formArray['mat_sub_type'] = $this->input->post('qtype');
            $formArray['unit'] = $this->input->post('unit');
            $formArray['location'] = $this->input->post('location');
            $formArray['gsm'] = $this->input->post('gsm');
            $formArray['sku'] = $this->input->post('sku');
            $formArray['quantity'] = $this->input->post('quantity');
            $formArray['width'] = $this->input->post('winch');
            $formArray['height'] = $this->input->post('hinch');
            $formArray['brand'] = $this->input->post('brand');
            $this->Category_model->update($id, $formArray);
            $this->session->set_flashdata('success', 'Stock Updated successfully');
            redirect(base_url() . 'admin/category/index');
        } else {
            $data['category'] = $category;
            $this->load->view('admin/category/edit', $data);
        }
    }

    public function delete()
    {
    }
}

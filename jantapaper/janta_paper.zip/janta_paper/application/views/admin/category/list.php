<?php $this->load->view('admin/header'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">Stock</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active">Stock</li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <?php if ($this->session->flashdata('success') != '') { ?>
                    <div class="alert alert-success"> <?php echo $this->session->flashdata('success'); ?></div>
                <?php } ?>

                <?php if ($this->session->flashdata('error') != '') { ?>
                    <div class="alert alert-danger"> <?php echo $this->session->flashdata('error'); ?></div>
                <?php } ?>

                <div class="card">
                    <div class="card-header">
                        <div class="card-tools">
                            <a href="<?php echo base_url() . 'admin/category/create' ?>" class="btn btn-primary"><i class="fas fa-plus"></i>&nbsp; Add Stock</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table" id="stockadd">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Presentation Type</th>
                                    <th>Quantity Type</th>
                                    <th>Unit</th>
                                    <th>Location</th>
                                    <th>GSM</th>
                                    <th>SKU</th>
                                    <th>Quantity</th>
                                    <th>Width</th>
                                    <th>Height</th>
                                    <th>Brand</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($categories)) { ?>
                                    <?php foreach ($categories as $categoryRow) { ?>
                                        <tr>
                                            <td class="text-center"><?php echo $categoryRow['id'] ?></td>
                                            <td class="text-center"><?php echo $categoryRow['material_type'] ?></td>
                                            <td class="text-center"><?php echo $categoryRow['mat_sub_type'] ?></td>
                                            <td class="text-center"><?php echo $categoryRow['unit'] ?></td>
                                            <td class="text-center"><?php echo $categoryRow['location'] ?></td>
                                            <td class="text-center"><?php echo $categoryRow['gsm'] ?></td>
                                            <td class="text-center"><?php echo $categoryRow['sku'] ?></td>
                                            <td class="text-center"><?php echo $categoryRow['quantity'] ?></td>
                                            <td class="text-center"><?php echo $categoryRow['width'] ?></td>
                                            <td class="text-center"><?php echo $categoryRow['height'] ?></td>
                                            <td class="text-center"><?php echo $categoryRow['brand'] ?></td>
                                            <td>
                                                <a href="<?php echo base_url() . 'admin/category/edit/' . $categoryRow['id']; ?>" class="btn btn-primary btn-sm">Edit</a>
                                                <a href="" class="btn btn-danger btn-sm">Delete</a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                <?php } else { ?>
                                    <tr>
                                        <td colspan="12">Records Not Found</td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
</div>
<!-- /.content -->
<?php $this->load->view('admin/footer'); ?>
<script>
    $(document).ready(function() {
        $('#stockadd').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        });
    });
</script>